import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/widgets.dart';
import '../models/profile.dart';
import 'key_sent_screen.dart';

class UnlockScreen extends StatefulWidget {
  const UnlockScreen({super.key, required this.profile});

  final DatingProfile profile;

  @override
  State<UnlockScreen> createState() => _UnlockScreenState();
}

class _UnlockScreenState extends State<UnlockScreen> {
  int selected = 0;
  final answerController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final profile = widget.profile;

    return Scaffold(
      appBar: AppBar(title: Text('${profile.name} için bir soru seç')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
          children: [
            Row(
              children: [
                ProfileAvatar(
                  initials: profile.initials,
                  size: 60,
                  locked: true,
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    '${profile.name} profilinin kapısını çal',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            for (int i = 0; i < profile.questions.length; i++) ...[
              InkWell(
                onTap: () => setState(() => selected = i),
                borderRadius: BorderRadius.circular(22),
                child: SoftCard(
                  color: selected == i ? AppColors.limeSoft : AppColors.surface,
                  child: Row(
                    children: [
                      Icon(
                        selected == i
                            ? Icons.radio_button_checked_rounded
                            : Icons.radio_button_unchecked_rounded,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          profile.questions[i],
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
            ],
            const SizedBox(height: 12),
            TextField(
              controller: answerController,
              maxLines: 5,
              maxLength: 300,
              decoration: const InputDecoration(
                hintText: 'Cevabını buraya yaz...',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Sesli cevap demo sürümünde yakında.',
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.mic_none_rounded),
              label: const Text('Sesle cevapla'),
            ),
            const SizedBox(height: 18),
            PrimaryButton(
              label: 'Knock gönder',
              icon: Icons.send_rounded,
              onPressed: () {
                final answer = answerController.text.trim().isEmpty
                    ? 'Gece herkes uyurken müzik dinlemek beni gerçekten rahatlatıyor.'
                    : answerController.text.trim();
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (_) => KeySentScreen(
                      profile: profile,
                      answer: answer,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
