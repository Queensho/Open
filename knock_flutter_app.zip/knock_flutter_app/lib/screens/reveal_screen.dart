import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/widgets.dart';
import 'chat_screen.dart';

class RevealScreen extends StatelessWidget {
  const RevealScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.ink,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              const Spacer(),
              const Icon(
                Icons.lock_open_rounded,
                size: 54,
                color: AppColors.lime,
              ),
              const SizedBox(height: 18),
              const Text(
                'Kapı açıldı!',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 34,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Birbirinizi artık daha yakından tanıyabilirsiniz.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 16),
              ),
              const SizedBox(height: 30),
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ProfileAvatar(initials: 'T', size: 96),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    child: Icon(
                      Icons.favorite_rounded,
                      color: AppColors.lime,
                      size: 34,
                    ),
                  ),
                  ProfileAvatar(initials: 'M', size: 96),
                ],
              ),
              const Spacer(),
              PrimaryButton(
                label: 'Merhaba de',
                icon: Icons.chat_bubble_rounded,
                onPressed: () {
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                      builder: (_) => const ChatScreen(name: 'Mert'),
                    ),
                  );
                },
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text(
                  'Şimdi değil',
                  style: TextStyle(color: Colors.white70),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
