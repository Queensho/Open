import 'package:flutter/material.dart';
import '../core/widgets.dart';
import 'chat_screen.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
        children: [
          const SectionHeader(
            title: 'Mesajlar',
            subtitle: 'Açılan sohbetlerin',
          ),
          const SizedBox(height: 20),
          SoftCard(
            child: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const ProfileAvatar(initials: 'M', size: 54),
              title: const Text(
                'Mert',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: const Text('En son hangi şarkıyı dinledin?'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const ChatScreen(name: 'Mert'),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
