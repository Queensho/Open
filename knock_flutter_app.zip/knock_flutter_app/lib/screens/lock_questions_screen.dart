import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/widgets.dart';
import 'main_shell.dart';

class LockQuestionsScreen extends StatefulWidget {
  const LockQuestionsScreen({super.key});

  @override
  State<LockQuestionsScreen> createState() => _LockQuestionsScreenState();
}

class _LockQuestionsScreenState extends State<LockQuestionsScreen> {
  final controllers = [
    TextEditingController(text: 'Bir ilişkide seni en çok ne mutlu eder?'),
    TextEditingController(text: 'İnsanların sende geç fark ettiği özellik ne?'),
    TextEditingController(text: 'Yarın hiçbir sorumluluğun olmasa ne yapardın?'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kilit soruları')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 28),
          children: [
            Text(
              'Profiline 3 kilit koy',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 8),
            Text(
              'Biri profilini açmak istediğinde bu sorulardan birini cevaplayacak.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 22),
            for (int i = 0; i < controllers.length; i++) ...[
              SoftCard(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: const BoxDecoration(
                        color: AppColors.lime,
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          '${i + 1}',
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        controller: controllers[i],
                        maxLines: 3,
                        decoration: const InputDecoration(
                          hintText: 'Sorunu yaz...',
                          border: InputBorder.none,
                          filled: false,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
            ],
            const SizedBox(height: 12),
            PrimaryButton(
              label: 'Profili tamamla',
              icon: Icons.arrow_forward_rounded,
              onPressed: () {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const MainShell()),
                  (route) => false,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
