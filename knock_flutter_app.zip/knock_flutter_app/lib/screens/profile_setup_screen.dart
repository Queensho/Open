import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/widgets.dart';
import 'lock_questions_screen.dart';

class ProfileSetupScreen extends StatefulWidget {
  const ProfileSetupScreen({super.key});

  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final nameController = TextEditingController(text: 'Tayfun');
  int age = 28;
  String intent = 'Ciddi ilişki';
  final interests = <String>{'Kahve', 'Müzik', 'Gezi'};

  @override
  Widget build(BuildContext context) {
    const chips = ['Kahve', 'Müzik', 'Gezi', 'Sinema', 'Spor', 'Kitap', 'Deniz'];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profilini oluştur'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 28),
          children: [
            Text(
              'Önce seni biraz tanıyalım.',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 8),
            Text(
              'Bu demo sürümünde bilgiler cihazda kalır.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 24),
            const Center(
              child: ProfileAvatar(initials: 'T', size: 104),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Adın',
                prefixIcon: Icon(Icons.person_outline_rounded),
              ),
            ),
            const SizedBox(height: 14),
            SoftCard(
              child: Row(
                children: [
                  const Icon(Icons.cake_outlined),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'Yaş',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() => age = (age - 1).clamp(18, 99)),
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
                  Text('$age', style: const TextStyle(fontWeight: FontWeight.w800)),
                  IconButton(
                    onPressed: () => setState(() => age = (age + 1).clamp(18, 99)),
                    icon: const Icon(Icons.add_circle_outline),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Ne arıyorsun?',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ['Ciddi ilişki', 'Flört', 'Tanışma', 'Emin değilim']
                  .map(
                    (value) => ChoiceChip(
                      label: Text(value),
                      selected: intent == value,
                      selectedColor: AppColors.lime,
                      onSelected: (_) => setState(() => intent = value),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 22),
            const Text(
              'İlgi alanların',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: chips.map((value) {
                final selected = interests.contains(value);
                return FilterChip(
                  label: Text(value),
                  selected: selected,
                  selectedColor: AppColors.limeSoft,
                  onSelected: (_) {
                    setState(() {
                      if (selected) {
                        interests.remove(value);
                      } else {
                        interests.add(value);
                      }
                    });
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 28),
            PrimaryButton(
              label: 'Kilit sorularını oluştur',
              icon: Icons.lock_outline_rounded,
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const LockQuestionsScreen(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
