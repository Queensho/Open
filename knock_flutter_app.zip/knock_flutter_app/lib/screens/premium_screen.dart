import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/widgets.dart';

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const features = [
      'Sınırsız Knock gönder',
      'Öne çıkar',
      'Gelişmiş filtreler',
      'Gizli mod',
      'Seyahat modu',
      'Gönderdiğin Knock’ları geri al',
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Knock+')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.ink,
                borderRadius: BorderRadius.circular(30),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.workspace_premium_rounded,
                    color: AppColors.lime,
                    size: 42,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Kapıları daha özgürce çal.',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Knock+ ile keşfetme deneyimini genişlet.',
                    style: TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            for (final feature in features)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  children: [
                    const Icon(
                      Icons.check_circle_rounded,
                      color: Color(0xFF87C900),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      feature,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 14),
            const SoftCard(
              color: AppColors.limeSoft,
              child: Column(
                children: [
                  Text(
                    '1 ay',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    '₺149,99',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    'Demo fiyatlandırma',
                    style: TextStyle(color: AppColors.muted),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            PrimaryButton(
              label: 'Knock+’ı dene',
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Ödeme bağlantısı production aşamasında eklenecek.',
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
