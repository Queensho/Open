import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/widgets.dart';
import '../models/profile.dart';

class KeySentScreen extends StatelessWidget {
  const KeySentScreen({
    super.key,
    required this.profile,
    required this.answer,
  });

  final DatingProfile profile;
  final String answer;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              const Spacer(),
              Container(
                width: 120,
                height: 120,
                decoration: const BoxDecoration(
                  color: AppColors.lime,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.notifications_active_rounded,
                  size: 58,
                  color: AppColors.ink,
                ),
              ),
              const SizedBox(height: 28),
              Text(
                'Knock gönderildi!',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 10),
              Text(
                '${profile.name} cevabını beğenirse profilini sana açabilecek.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: AppColors.muted,
                    ),
              ),
              const SizedBox(height: 18),
              SoftCard(
                child: Text(
                  '“$answer”',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 14),
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.schedule_rounded, size: 18),
                  SizedBox(width: 6),
                  Text('48 saat içinde yanıtlanır'),
                ],
              ),
              const Spacer(),
              PrimaryButton(
                label: 'Keşfete dön',
                onPressed: () => Navigator.of(context).pop(),
                dark: true,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
