import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/widgets.dart';
import 'profile_setup_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final controller = PageController();
  int index = 0;

  final pages = const [
    _OnboardData(
      title: 'Profilleri kaydırma.\nKapıyı çal.',
      body: 'Fotoğrafa göre karar vermek yerine önce merak et.',
      icon: Icons.touch_app_rounded,
    ),
    _OnboardData(
      title: 'Bir soru seç.\nKendini göster.',
      body: 'Profil sahibinin üç sorusundan birini cevapla.',
      icon: Icons.question_answer_rounded,
    ),
    _OnboardData(
      title: 'Cevabın beğenilirse\nprofil açılır.',
      body: 'İkiniz de isterseniz konuşma başlar. Daha az eşleşme, daha gerçek tanışma.',
      icon: Icons.lock_open_rounded,
    ),
  ];

  void next() {
    if (index < pages.length - 1) {
      controller.nextPage(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOut,
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const ProfileSetupScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 20),
          child: Column(
            children: [
              Row(
                children: [
                  const KnockWordmark(size: 30),
                  const Spacer(),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(
                          builder: (_) => const ProfileSetupScreen(),
                        ),
                      );
                    },
                    child: const Text('Geç'),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              Expanded(
                child: PageView.builder(
                  controller: controller,
                  itemCount: pages.length,
                  onPageChanged: (value) => setState(() => index = value),
                  itemBuilder: (context, i) {
                    final p = pages[i];
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Spacer(),
                        Container(
                          height: 310,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: i == 1 ? AppColors.ink : AppColors.surface,
                            borderRadius: BorderRadius.circular(34),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Center(
                            child: Container(
                              width: 118,
                              height: 118,
                              decoration: const BoxDecoration(
                                color: AppColors.lime,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                p.icon,
                                size: 56,
                                color: AppColors.ink,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 34),
                        Text(
                          p.title,
                          style: Theme.of(context).textTheme.displaySmall,
                        ),
                        const SizedBox(height: 14),
                        Text(
                          p.body,
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge
                              ?.copyWith(color: AppColors.muted),
                        ),
                        const Spacer(),
                      ],
                    );
                  },
                ),
              ),
              Row(
                children: List.generate(
                  pages.length,
                  (i) => AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: i == index ? 26 : 8,
                    height: 8,
                    margin: const EdgeInsets.only(right: 7),
                    decoration: BoxDecoration(
                      color: i == index ? AppColors.ink : AppColors.border,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              PrimaryButton(
                label: index == pages.length - 1 ? 'Başlayalım' : 'Devam',
                onPressed: next,
                icon: Icons.arrow_forward_rounded,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _OnboardData {
  const _OnboardData({
    required this.title,
    required this.body,
    required this.icon,
  });

  final String title;
  final String body;
  final IconData icon;
}
