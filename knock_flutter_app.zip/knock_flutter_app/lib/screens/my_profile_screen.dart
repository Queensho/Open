import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../core/widgets.dart';
import 'premium_screen.dart';

class MyProfileScreen extends StatelessWidget {
  const MyProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
        children: [
          const SectionHeader(
            title: 'Profil',
            subtitle: 'Kendini nasıl gösterdiğini yönet',
          ),
          const SizedBox(height: 22),
          const Center(child: ProfileAvatar(initials: 'T', size: 104)),
          const SizedBox(height: 12),
          const Center(
            child: Text(
              'Tayfun, 28',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(height: 4),
          const Center(
            child: Text(
              'Ciddi ilişki',
              style: TextStyle(color: AppColors.muted),
            ),
          ),
          const SizedBox(height: 22),
          SoftCard(
            child: Column(
              children: [
                _ProfileItem(
                  icon: Icons.edit_outlined,
                  title: 'Profili düzenle',
                  onTap: () {},
                ),
                const Divider(height: 24),
                _ProfileItem(
                  icon: Icons.lock_outline_rounded,
                  title: 'Kilit sorularım',
                  onTap: () {},
                ),
                const Divider(height: 24),
                _ProfileItem(
                  icon: Icons.visibility_outlined,
                  title: 'Profil önizleme',
                  onTap: () {},
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          InkWell(
            borderRadius: BorderRadius.circular(24),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const PremiumScreen()),
              );
            },
            child: const SoftCard(
              color: AppColors.limeSoft,
              child: Row(
                children: [
                  Icon(Icons.workspace_premium_rounded, size: 34),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Knock+',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text('Daha fazla anahtar ve gelişmiş filtreler'),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          SoftCard(
            child: Column(
              children: [
                _ProfileItem(
                  icon: Icons.shield_outlined,
                  title: 'Güvenlik',
                  onTap: () {},
                ),
                const Divider(height: 24),
                _ProfileItem(
                  icon: Icons.settings_outlined,
                  title: 'Ayarlar',
                  onTap: () {},
                ),
                const Divider(height: 24),
                _ProfileItem(
                  icon: Icons.help_outline_rounded,
                  title: 'Yardım',
                  onTap: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileItem extends StatelessWidget {
  const _ProfileItem({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          const Icon(Icons.chevron_right_rounded),
        ],
      ),
    );
  }
}
