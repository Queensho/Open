class DatingProfile {
  const DatingProfile({
    required this.name,
    required this.age,
    required this.distanceKm,
    required this.initials,
    required this.job,
    required this.city,
    required this.tags,
    required this.questions,
    required this.about,
  });

  final String name;
  final int age;
  final int distanceKm;
  final String initials;
  final String job;
  final String city;
  final List<String> tags;
  final List<String> questions;
  final String about;
}

const demoProfiles = <DatingProfile>[
  DatingProfile(
    name: 'Elif',
    age: 27,
    distanceKm: 4,
    initials: 'E',
    job: 'UX Designer',
    city: 'İstanbul',
    tags: ['Kahve', 'Sinema', 'Deniz'],
    questions: [
      'Hayatındaki mükemmel pazar günü nasıl olurdu?',
      'Seni anında soğutan davranış nedir?',
      'Son zamanlarda seni gerçekten güldüren şey neydi?',
    ],
    about:
        'Sakin planları, uzun yürüyüşleri ve yeni kahveciler keşfetmeyi seviyorum.',
  ),
  DatingProfile(
    name: 'Derya',
    age: 29,
    distanceKm: 7,
    initials: 'D',
    job: 'Mimar',
    city: 'İstanbul',
    tags: ['Mimari', 'Konser', 'Seyahat'],
    questions: [
      'Bir günlüğüne istediğin yerde olsan neresi olurdu?',
      'İlişkide senin için vazgeçilmez olan nedir?',
      'Seni en hızlı ne güldürür?',
    ],
    about: 'Yeni şehirler, iyi müzik ve beklenmedik planlar.',
  ),
  DatingProfile(
    name: 'Selin',
    age: 26,
    distanceKm: 10,
    initials: 'S',
    job: 'Editör',
    city: 'İstanbul',
    tags: ['Kitap', 'Brunch', 'Fotoğraf'],
    questions: [
      'Sence iyi bir ilk buluşma nasıl olmalı?',
      'Son zamanlarda öğrendiğin en ilginç şey ne?',
      'Bir insanı sana yakın hissettiren şey nedir?',
    ],
    about: 'Kitapçı gezmek ve şehirde yeni yerler bulmak favorim.',
  ),
];
