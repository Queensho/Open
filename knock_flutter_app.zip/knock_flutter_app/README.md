# Knock

**Knock**; klasik sağa/sola kaydırma yerine, bir profilin kilidini soru-cevap üzerinden açmaya dayalı Flutter flört uygulaması MVP'sidir.

## İçerik

- Splash ve 3 adımlı onboarding
- Profil kurulum akışı
- 3 kilit sorusu oluşturma
- Keşfet ekranı
- Profil kilidi açma
- Soru seçme ve cevap gönderme
- Gelen anahtarlar
- Profil açılma / eşleşme ekranı
- Mesajlar ve çalışan demo sohbet
- Profil / ayarlar / premium ekranı
- Siyah + beyaz + neon lime tasarım sistemi
- Harici paket veya API gerektirmez
- Demo veriler ile internetsiz çalışır

## Çalıştırma

Bu repo `lib/` ve Flutter yapılandırmasını içerir. Platform klasörlerini bir kez üret:

```bash
flutter create . --platforms=android,web --project-name knock_app
flutter pub get
flutter run
```

### GitHub Codespaces / başka bulut IDE

Flutter kuruluysa yukarıdaki üç komut yeterlidir.

## GitHub Actions

`.github/workflows/flutter.yml` her push'ta:
1. Flutter kurar
2. Android/Web platform klasörlerini üretir
3. `flutter pub get`
4. `flutter analyze`
5. Web build alır

## Not

Bu sürüm **çalışan frontend/MVP**'dir ve demo verileri yerel bellekte tutar. Gerçek kullanıcı hesabı, gerçek mesajlaşma, fotoğraf yükleme, bildirim, eşleştirme motoru, moderasyon ve veritabanı için sonraki aşamada Firebase veya Supabase entegrasyonu gerekir.
